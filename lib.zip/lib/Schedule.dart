import 'package:hive/hive.dart';

part 'Schedule.g.dart';

@HiveType(typeId: 0)
class Schedule extends HiveObject {
  @HiveField(0)
  String title;

  @HiveField(1)
  String location;

  @HiveField(2)
  String content;

  @HiveField(3)
  String type;

  @HiveField(4)
  String date; // yyyy-MM-dd

  Schedule({required this.title, required this.location, required this.content, required this.type, required this.date});
}
